function js_search() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue, field;
  input = document.getElementById("fast_search");
  field="div";
  if (document.getElementById("onlyCompany").checked == true) {field="strong"};
  filter = input.value.toUpperCase();
  table = document.getElementById("cardholder");
  tr = table.getElementsByClassName("card");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName(field)[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}