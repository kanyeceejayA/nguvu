<?php
header('location:startups');